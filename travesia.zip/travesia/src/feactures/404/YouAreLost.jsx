import React from 'react'

export default function YouAreLost() {
  return (
    <div>YouAreLost</div>
  )
}
