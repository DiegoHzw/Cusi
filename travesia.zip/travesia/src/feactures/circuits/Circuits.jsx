import React from 'react'

export default function Circuits() {
  return (
    <div>circuits</div>
  )
}
