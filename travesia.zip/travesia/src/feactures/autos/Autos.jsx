import React from 'react'
import Bannerautos from './banner/Bannerautos'

export default function Autos() {
  return (
    <div>Autos
        <Bannerautos></Bannerautos>
    </div>

  )
}
