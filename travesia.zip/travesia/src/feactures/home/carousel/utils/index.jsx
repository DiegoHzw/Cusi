export { chunk } from "./chunk";
export { getNextSlide, getPrevSlide } from "./getSlide";
export { mockedSlides } from "./mockedSlides";
