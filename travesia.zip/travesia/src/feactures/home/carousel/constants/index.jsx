export const MOBILE_SLIDES_COUNT = 1;
export const DESKTOP_SLIDES_COUNT = 1;
export const MOBILE_VIEW = 768;
export const SLIDE_DELAY = 5000;
